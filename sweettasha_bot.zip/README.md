# Sweettasha Discord Bot

A simple Discord bot to greet users and handle basic commands.

## How to run locally
1. Install dependencies:
```
npm install
```

2. Run the bot:
```
DISCORD_TOKEN=your_token_here node index.js
```

## Commands
- `hello` — Greets you
- `help` — Shows commands
