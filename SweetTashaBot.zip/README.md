# SweetTashaBot
A branded Discord bot with free trial functionality.

## Setup
1. Add your `DISCORD_BOT_TOKEN` in Railway environment variables.
2. Deploy the bot on Railway.
3. Invite it to your server using your bot invite link.

Command:
- `!trial` - Activates a free trial message.
